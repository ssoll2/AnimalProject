const slides = document.querySelector(".slide_list");
const paginationElem = document.querySelector(".pagination");

const slideCount = slides.children.length; // 슬라이드 개수 (클론 포함)
const originalSlideCount = 5; // 원본 슬라이드 개수 (클론 제외)
const slideWidth = slides.clientWidth; // 슬라이드 너비
let currentIndex = 0; // 현재 슬라이드 인덱스
let isTransitioning = false; // 애니메이션 상태
let interval; // 자동 슬라이드 interval 변수
let prevPagination; // 이전 활성화된 페이지네이션

// 슬라이드 클론 추가
const firstClone = slides.children[0].cloneNode(true);
const lastClone = slides.children[originalSlideCount - 1].cloneNode(true);
slides.appendChild(firstClone); // 첫 슬라이드 클론 추가
slides.insertBefore(lastClone, slides.children[0]); // 마지막 슬라이드 클론 추가

// 초기 슬라이드 위치 설정
slides.style.transform = `translateX(-${slideWidth}px)`;

// 페이지네이션 생성
function pagination() {
    for (let i = 0; i < originalSlideCount; i++) {
        const createLI = document.createElement("li"); // li 요소 생성
        createLI.setAttribute("class", `pagination-${i}`); // 클래스 이름 설정
        paginationElem.appendChild(createLI); // 페이지네이션 ul에 li 추가
    }
    const firstPagination = document.querySelector(".pagination li");
    prevPagination = firstPagination;
    prevPagination.classList.add("active"); // 첫 번째 페이지네이션 항목 활성화
}

// 페이지네이션 업데이트
function updatePagination(index) {
    if (prevPagination) prevPagination.classList.remove("active");
    const currentPagination = document.querySelector(`.pagination li.pagination-${index}`);
    if (currentPagination) {
        currentPagination.classList.add("active");
        prevPagination = currentPagination;
    }
}

// 슬라이드 이동
function moveSlide(index) {
    if (isTransitioning) return; // 애니메이션 중일 때 실행 방지
    isTransitioning = true;

    slides.style.transition = "transform 0.5s ease";
    slides.style.transform = `translateX(-${(index + 1) * slideWidth}px)`; // 클론 고려한 위치 이동
    currentIndex = index;

    slides.addEventListener("transitionend", () => {
        isTransitioning = false;

        // 클론 슬라이드 처리
        if (currentIndex === -1) {
            slides.style.transition = "none";
            slides.style.transform = `translateX(-${originalSlideCount * slideWidth}px)`;
            currentIndex = originalSlideCount - 1;
        } else if (currentIndex === originalSlideCount) {
            slides.style.transition = "none";
            slides.style.transform = `translateX(-${slideWidth}px)`;
            currentIndex = 0;
        }

        updatePagination(currentIndex); // 페이지네이션 업데이트
    });
}

// 자동 슬라이드
function autoSlide() {
    interval = setInterval(() => {
        moveSlide(currentIndex + 1);
    }, 3000);
}

// 페이지네이션 클릭 처리
function paginationHandler(event) {
    if (event.target.nodeName === "UL") return; // 클릭한 곳이 UL이면 무시
    const index = parseInt(event.target.className.split("-")[1], 10);
    clearInterval(interval); // 자동 슬라이드 중단
    moveSlide(index);
    autoSlide(); // 자동 슬라이드 재시작
}

// 초기화
function init() {
    pagination(); // 페이지네이션 생성
    autoSlide(); // 자동 슬라이드 시작
    paginationElem.addEventListener("click", paginationHandler); // 페이지네이션 클릭 이벤트 등록
}

// 초기화 실행
init();
